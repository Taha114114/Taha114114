package tests;

import java.io.IOException;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pages.*;
import testbase.TestBase;


public class RegisterTests extends TestBase{

	ExtentTest test;
	ExtentReports report;
	
	RegisterPage page;
	MyAccountPage  welcomepage;
	
	String URL;
	String FirstName;
	String LastName;
	String Phone;
	String Email;
	String Password;
	

	public RegisterTests() throws IOException {
		URL=getObject("URL");
		FirstName=getObject("FirstName");
		LastName=getObject("LastName");
		Phone=getObject("Phone");
		Email=getObject("Email");
		Password=getObject("Password");
	}
	
	@BeforeSuite
	public void BeforeSuite(){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd_MM_yyyy");
		LocalDate today = LocalDate.now(); 
   	 	todayString=formatter.format(today); 	
   	 	
   	 	report = new ExtentReports(System.getProperty("user.dir")+"\\test-output\\"+todayString+"_Report.html");
		test = report.startTest("Pixelogic Report");
	}
	
	@BeforeMethod
	public void setup() throws IOException {
		driver=new ChromeDriver();
		page = new RegisterPage();
		welcomepage = new MyAccountPage();
	}
	
	@AfterMethod
	public void teardown(ITestResult result) throws IOException{
		if(result.isSuccess()){
			test.log(LogStatus.PASS,result.getMethod().getMethodName().toString());
		}else{
			test.log(LogStatus.FAIL,result.getMethod().getMethodName().toString());
			test.log(LogStatus.INFO,test.addScreenCapture(testutil.TakeScreenShoot.capture(driver)));
		}
	
		driver.quit();
	}
	
	@AfterSuite
	public void aftersuite() throws IOException{
		report.endTest(test);
		report.flush();
		
		Runtime.getRuntime().exec("TASKKILL  /F /IM chromedriver.exe");
	}
	
	
	@Test (priority=10)
	public void HTTP_Interceptor() throws MalformedURLException, IOException{
	    driver.get(URL);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    List<WebElement> links = driver.findElements(By.tagName("a"));
	    for(int i = 0; i < links.size(); i++){
	    	if(!(links.get(i).getAttribute("href") == null) && !(links.get(i).getAttribute("href").equals(""))){
	           if(links.get(i).getAttribute("href").contains("http")){
	           	 testutil.GetResponseData.getdata(links.get(i).getAttribute("href"));
		       }
	        }   
	    }   
	}
	
	@Test (priority=20)
	public void validregister() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName, LastName, Phone, Email, Password);
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName);
	}

	@Test (priority=30)
	public void invalidregister_LowercaseFirstname() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName.toLowerCase(), LastName, Phone, Email, Password);
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName); //this test case will fail
	}

	@Test (priority=40)
	public void invalidregister_LowercaseLasttname() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName, LastName.toLowerCase(), Phone, Email, Password);
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName); //this test case will fail
	}
	
	@Test (priority=50)
	public void invalidregister_noPhone() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName, LastName, "", Email, Password);
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName); //this test case will fail
	}

	@Test (priority=60)
	public void invalidregister_InvalidEmail() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName, LastName, Phone, "1234567890", Password);
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName); //this test case will fail
	}

	@Test (priority=70)
	public void invalidregister_notcorrectPassword() throws IOException, InterruptedException {
		String welcomemessage=Registersteps(driver, page, URL, FirstName, LastName, Phone, Email, Password.toLowerCase());
		Assert.assertEquals(welcomemessage, "Hi, "+FirstName+" "+LastName); //this test case will fail
	}

	
	//Steps of registration to be reused in all test cases  
	public String Registersteps(WebDriver driver,RegisterPage page, String URL, String FirstName, String LastName,String Phone, String Email, String Password){
		page.seturl(driver, URL);
		page.setfirstname(driver,FirstName);
		page.setlastname(driver,LastName);
		page.setphone(driver,Phone);
		page.setemail(driver,Email);
		page.setpassword(driver,Password);
		page.setpasswordconfirm(driver,Password);
		page.clicksignupbutton(driver);
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		return welcomepage.getwm(driver);
	}
}
