package testutil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import testbase.TestBase;

public class WriteLogFile extends TestBase{
	public static void AddtologFile(String text) throws IOException{
	     BufferedWriter output = null;
	     try {
	    	 String completefilename=System.getProperty("user.dir")+"\\test-output\\"+todayString+"interceptor.txt";
	         File file = new File(completefilename);
	         output = new BufferedWriter(new FileWriter(file,true));
	         output.newLine();
	         output.write(text);
	     } catch ( IOException e ) {
	         e.printStackTrace();
	     } finally {
	       if ( output != null ) {
	         output.close();
	       
	       }
	     }
	}
}

