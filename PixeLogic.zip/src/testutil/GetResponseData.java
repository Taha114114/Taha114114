package testutil;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;


import testbase.TestBase;

public class GetResponseData extends TestBase{


	public static void getdata(String urlString) throws MalformedURLException, IOException{
		java.net.URL url = new java.net.URL(urlString);
	    HttpURLConnection huc = (HttpURLConnection)url.openConnection();
	    huc.setRequestMethod("GET");
	    huc.connect();
	    
	    WriteLogFile.AddtologFile(urlString);
	    WriteLogFile.AddtologFile(String.valueOf(huc.getResponseCode()));
	    WriteLogFile.AddtologFile(String.valueOf(huc.getResponseMessage()));
	    WriteLogFile.AddtologFile("");
	    //We can list any response attribute we need here
	}
	

}
