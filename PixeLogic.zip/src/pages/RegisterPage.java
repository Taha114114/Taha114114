package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import testbase.TestBase;

public class RegisterPage extends TestBase{
	
	private By firstname		=By.xpath("//*[@id='headersignupform']/div[3]/div[1]/div/label/input");
	private By lastname			=By.xpath("//*[@id='headersignupform']/div[3]/div[2]/div/label/input");
	private By phone			=By.xpath("//*[@id='headersignupform']/div[4]/label/input");
	private By email			=By.xpath("//*[@id='headersignupform']/div[5]/label/input");
	private By password			=By.xpath("//*[@id='headersignupform']/div[6]/label/input");
	private By passwordconfirm	=By.xpath("//*[@id='headersignupform']/div[7]/label/input");
	private By signupbutton		=By.xpath("//*[@id='headersignupform']/div[8]/button");
	/////////////////////////////////
	public void seturl(WebDriver driver, String url) {
		driver.get(url);
		driver.manage().window().maximize();
	}

	public void setfirstname(WebDriver driver, String FN) {
		driver.findElement(firstname).sendKeys(FN);
	}
	
	public void setlastname(WebDriver driver,String LN) {
		driver.findElement(lastname).sendKeys(LN);
	}
	
	public void setphone(WebDriver driver,String pn) {
		driver.findElement(phone).sendKeys(pn);
	}

	public void setemail(WebDriver driver,String eml) {
		driver.findElement(email).sendKeys(eml);
	}
	
	public void setpassword(WebDriver driver,String pswrd) {
		driver.findElement(password).sendKeys(pswrd);
	}

	public void setpasswordconfirm(WebDriver driver,String pswrdcnfrm) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(signupbutton));
		driver.findElement(passwordconfirm).sendKeys(pswrdcnfrm);
	}
	
	public void clicksignupbutton(WebDriver driver) {
			driver.findElement(signupbutton).click();
	}
	
}
