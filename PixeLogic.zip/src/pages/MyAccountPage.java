package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import testbase.TestBase;

public class MyAccountPage extends TestBase{
	private By WelcomMessage		=By.xpath("/html/body/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/h3");
	
	public String getwm(WebDriver driver) {
		return driver.findElement(WelcomMessage).getText();
	}
	
}
